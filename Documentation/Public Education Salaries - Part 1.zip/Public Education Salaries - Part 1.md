
___
_2018 | Bernard Kung _
___

# Public Education Salaries

___
In this series of notebooks I'm going to explore the publicly available data on public education salaries with a specific goal of investigating the salary differences between administrators and teachers, both in terms of what these salary differences are and how they're caused. It's also an excellent opportunity for me to develop practical experience with Python and it's array of analytics and visualization packages.

My data for this notebook are the 2015-2016 Pennsylvania salaries for persons in public education. It was sourced from [The York Daily Record](https://www.ydr.com/story/news/watchdog/2017/08/24/teacher-salary-database-2016-17-how-much-pennsylvania-educators-get-paid/594170001/), which prints in an easily copied format but is updated every year and is currently only displaying 2016-2017. Alternatively, [openPAgov.org](http://www.openpagov.org) provides all this same information for corroboration.

Data was copied into a .csv file and is hosted in this project repo, and accessed directly from the github raw file.


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
```


```python
%matplotlib inline
```


```python
file_url = 'https://raw.githubusercontent.com/bernardkung/TeacherSalary/master/2015_2016_PA_Salaries.csv'
data_raw = pd.read_csv(file_url, encoding='latin1')
```


```python
data_raw.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>School District</th>
      <th>Job Category</th>
      <th>Position</th>
      <th>Assignment</th>
      <th>YearsInLEA</th>
      <th>YearsInEd</th>
      <th>Highest Degree</th>
      <th>Annual Salary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>HAIN, JOEL K</td>
      <td>South Middleton SD</td>
      <td>Administrative / Supervisory</td>
      <td>School Administrator</td>
      <td>Secondary Principal</td>
      <td>3</td>
      <td>16</td>
      <td>Master's degree</td>
      <td>$107,424</td>
    </tr>
    <tr>
      <th>1</th>
      <td>APPLE, EDWARD E</td>
      <td>Juniata County SD</td>
      <td>Administrative / Supervisory</td>
      <td>School Administrator</td>
      <td>Secondary Principal</td>
      <td>21</td>
      <td>21</td>
      <td>Master's degree</td>
      <td>$94,181</td>
    </tr>
    <tr>
      <th>2</th>
      <td>RUMMEL, JAMES S</td>
      <td>Armstrong SD</td>
      <td>Administrative / Supervisory</td>
      <td>School Administrator</td>
      <td>Secondary Principal</td>
      <td>13</td>
      <td>25</td>
      <td>Master's degree</td>
      <td>$104,207</td>
    </tr>
    <tr>
      <th>3</th>
      <td>STAGE, CRAIG</td>
      <td>Athens Area SD</td>
      <td>Administrative / Supervisory</td>
      <td>Chief School Administrator</td>
      <td>Acting Superintendent</td>
      <td>3</td>
      <td>14</td>
      <td>Master's degree</td>
      <td>$130,000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>KEPLER, BERNARD CHARLES</td>
      <td>Palmyra Area SD</td>
      <td>Administrative / Supervisory</td>
      <td>LEA Administrator</td>
      <td>Assistant Superintendent</td>
      <td>2</td>
      <td>18</td>
      <td>Doctoral degree</td>
      <td>$130,907</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_raw.shape
```




    (146744, 9)



### Taking Care of Some Minor Problems

So there's two main things I want to do: First, remove the whitespace from the column names; not a crucial task, but fits my stylistic preferences. Second, and more importantly, the **AnnualSalary** column is actually a _string_, and needs to be converted to a _numeric_ data type.

Working with column names I'll use the _rename()_ method. Since white spaces are in the middle, I'll use _replace()_, and use a lambda function to apply it to all column names. Finally, _inplace_ argument has to be set to keep the changes.


```python
data = data_raw
data.rename(columns=lambda x: x.replace(' ',''), inplace = True)
```


```python
data.columns.values
```




    array(['Name', 'SchoolDistrict', 'JobCategory', 'Position', 'Assignment',
           'YearsInLEA', 'YearsInEd', 'HighestDegree', 'AnnualSalary'],
          dtype=object)



Here both _strip()_ and _replace()_ are used with lambda functions to apply to all rows in the **AnnualSalary** column: the former to remove the dollar signs, and the latter to remove commas.
The strings then coerce cleanly to integers.


```python
data['AnnualSalary'] = data_raw['AnnualSalary'].apply(lambda x: x.strip('$'))
data['AnnualSalary'] = data_raw['AnnualSalary'].apply(lambda x: x.replace(',',''))
data['AnnualSalary'] = data_raw['AnnualSalary'].astype(int)
data['AnnualSalary'].head()
```




    0    107424
    1     94181
    2    104207
    3    130000
    4    130907
    Name: AnnualSalary, dtype: int32



Data is now in the preferred format. Exploratory analysis was mostly performed in R, see separate notebook for additional details.


```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>YearsInLEA</th>
      <th>YearsInEd</th>
      <th>AnnualSalary</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>146744.000000</td>
      <td>146744.000000</td>
      <td>146744.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>11.780448</td>
      <td>13.521411</td>
      <td>67405.910116</td>
    </tr>
    <tr>
      <th>std</th>
      <td>8.040157</td>
      <td>8.572739</td>
      <td>20353.632473</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>39.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>6.000000</td>
      <td>7.000000</td>
      <td>52257.750000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>11.000000</td>
      <td>12.000000</td>
      <td>64527.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>17.000000</td>
      <td>19.000000</td>
      <td>79282.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>60.000000</td>
      <td>66.000000</td>
      <td>304523.000000</td>
    </tr>
  </tbody>
</table>
</div>



### We Don't Need No Education

So let's get into it: what can we say about the differences in educator salaries between administrators and teachers?

My starting point is a histogram of all annual salaries; while we have a basic idea of how salaries are distributed thanks to the _describe()_ call above giving us basic exploratory statistics like median and IQR, those statistics are fitted for normal distributions and a histogram is a natural next step in case of something like bimodal distribution that the exploratory statistics may not reveal.

In the annual salary histogram below, the basic distribution of salaries doesn't seem to be hiding any real surprises. It's clear that the majority of the data is actually fairly tightly grouped between \$40,000 to \$120,000. There's a short tail of salaries to the left, and a significantly longer tail of salaries ranging as high as \$300,000.


```python
dims = (12, 8)
fig, ax = plt.subplots(figsize=dims)
sns.distplot(data['AnnualSalary'], kde=False, ax=ax)
ax.set(ylabel = 'Count', title = 'Histogram of Annual Salaries')
```




    [Text(0,0.5,'Count'), Text(0.5,1,'Histogram of Annual Salaries')]




![png](output_17_1.png)


With a basic idea of the distribution of the salaries, the natural next question is how do the salaries vary between job categories?

The **JobCategory** column has four unique values: Adminstrative/Supervisory, Classroom Teachers, Coordinate Services, and Others. These are further broken down in the **Position** column to specify each person's exact role.




```python
data.groupby(['JobCategory','Position']).size()
```




    JobCategory                   Position                      
    Administrative / Supervisory  Chief School Administrator          712
                                  LEA Administrator                   218
                                  School Administrator               4564
                                  Supervisor / Coordinator           1567
    Classroom Teachers            Elementary Special Ed. Teacher     5776
                                  Elementary Teacher                51164
                                  Secondary Special Ed. Teacher      2772
                                  Secondary Teacher                 49307
                                  Ungraded Special Ed. Teacher       9101
                                  Ungraded Teacher                    762
    Coordinate Services           Guidance                           4347
                                  Health / Welfare                   4484
                                  Operations                         1311
                                  Specialist                         4892
    Others                        Other                              5767
    dtype: int64



So starting with the higher level **JobCategory** column, how do salaries break down? Here a violin plot is used to simultaneously draw both the distribution and the exploratory statistics. 


```python
dims = (12, 8)
fig, ax = plt.subplots(figsize=dims)
sns.violinplot(x='AnnualSalary', y='JobCategory', data=data, ax=ax)
ax.set(title = 'Distribution of Annual Salary by Job Category')
```




    [Text(0.5,1,'Distribution of Annual Salary by Job Category')]




![png](output_21_1.png)


There's a few things that stand out to me:

1. The same basic left skewed distribution shows up across all job categories, with a lot of low-end salaries being balanced out by long right tails.
2. Administrators are clearly paid a lot more. 
    * The median is clearly higher by \$20,000 to \$30,000
    * The upper range of salaries above \$220,000 are all administrative. 
    * Out of all the categories, the left skew is least pronounced and looks the most normally distributed with the median lining up with the histogram peak. 
3. Classroom teacher actually look like they're paid the least out of all the categories.
    * The median, 25th, and 75th quartile are each the lowest out of all the categories.
    * The left skew is not only the most pronounced for teachers, the distribution peaks at a lower salary than all other categories.
    * However, in terms of distributions classroom teachers and coordinate services are actually very closely distributed. 

There's also a final consideration to keep in mind: these plots have actually be re-scaled to all be the same size. The count plot below illustrates what the _size()_ call above showed: there are drastically more teachers than people in any of the other categories. The violin plots, unscaled, would be proportionally flat 


```python
dims = (12, 8)
fig, ax = plt.subplots(figsize=dims)
sns.countplot(x='JobCategory', data=data)
ax.set(title = 'Distribution of Work Force by Job Category', ylabel = 'Number of People')
```




    [Text(0,0.5,'Number of People'),
     Text(0.5,1,'Distribution of Work Force by Job Category')]




![png](output_23_1.png)


### The Hunger Games: But Actually Salaries

One of the problems here is that there's too many other variables that haven't been considered and it's difficult to draw conclusive insights. So why start with school districts? The goal is to create groups that will be as uniform as possible within each group to reduce the effects of any extraneous variables. It's easier to imagine conditions are more similar for everyone in a school district than compared to all first year teachers across the state. That being said, this is just an intuited starting point, and it's entirely possible my hypothesis is false.

The goal is to essentially build a multi-index table with the two indices I'm interested in: **SchoolDistrict** and **JobCategory**, and aggregating various information across these variables. These would include:

* Counts of persons and their distribution to help determine district size
* Averages and distributions of Years in LEA, Years in Education, Annual Salary
* Totals of Annual Salary to help determine district 'wealth'



```python
data['SchoolDistrict'].nunique()
```




    769




```python
district_category_data = data.groupby(['SchoolDistrict','JobCategory']).mean()
```


```python
district_category_data['TotalSalary'] = data.groupby(['SchoolDistrict','JobCategory']).sum()['AnnualSalary']
```


```python
district_category_data['TotalPersons'] = data.groupby(['SchoolDistrict','JobCategory']).count()['Name']
```


```python
district_category_data.columns = ['AvgYearsInLEA','AvgYearsInEd','AvgAnnualSalary','SumSalaries','SumPersons']
```


```python
district_category_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>AvgYearsInLEA</th>
      <th>AvgYearsInEd</th>
      <th>AvgAnnualSalary</th>
      <th>SumSalaries</th>
      <th>SumPersons</th>
    </tr>
    <tr>
      <th>SchoolDistrict</th>
      <th>JobCategory</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="4" valign="top">-</th>
      <th>Administrative / Supervisory</th>
      <td>2.038462</td>
      <td>11.192308</td>
      <td>80109.653846</td>
      <td>2082851</td>
      <td>26</td>
    </tr>
    <tr>
      <th>Classroom Teachers</th>
      <td>1.900524</td>
      <td>4.188482</td>
      <td>45629.591623</td>
      <td>8715252</td>
      <td>191</td>
    </tr>
    <tr>
      <th>Coordinate Services</th>
      <td>1.500000</td>
      <td>5.583333</td>
      <td>55764.583333</td>
      <td>669175</td>
      <td>12</td>
    </tr>
    <tr>
      <th>Others</th>
      <td>1.846154</td>
      <td>11.230769</td>
      <td>41646.153846</td>
      <td>541400</td>
      <td>13</td>
    </tr>
    <tr>
      <th>21st Century Cyber CS</th>
      <th>Administrative / Supervisory</th>
      <td>4.333333</td>
      <td>14.666667</td>
      <td>104567.000000</td>
      <td>313701</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
district_data = district_category_data.unstack()
```


```python
district_data['TotalAnnualSalary'] = district_data['AvgAnnualSalary'].sum(axis=1)
district_data['TotalPersons'] = district_data['SumPersons'].sum(axis=1)
```


```python
district_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="4" halign="left">AvgYearsInLEA</th>
      <th colspan="4" halign="left">AvgYearsInEd</th>
      <th colspan="2" halign="left">AvgAnnualSalary</th>
      <th>...</th>
      <th colspan="4" halign="left">SumSalaries</th>
      <th colspan="4" halign="left">SumPersons</th>
      <th>TotalAnnualSalary</th>
      <th>TotalPersons</th>
    </tr>
    <tr>
      <th>JobCategory</th>
      <th>Administrative / Supervisory</th>
      <th>Classroom Teachers</th>
      <th>Coordinate Services</th>
      <th>Others</th>
      <th>Administrative / Supervisory</th>
      <th>Classroom Teachers</th>
      <th>Coordinate Services</th>
      <th>Others</th>
      <th>Administrative / Supervisory</th>
      <th>Classroom Teachers</th>
      <th>...</th>
      <th>Administrative / Supervisory</th>
      <th>Classroom Teachers</th>
      <th>Coordinate Services</th>
      <th>Others</th>
      <th>Administrative / Supervisory</th>
      <th>Classroom Teachers</th>
      <th>Coordinate Services</th>
      <th>Others</th>
      <th></th>
      <th></th>
    </tr>
    <tr>
      <th>SchoolDistrict</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>-</th>
      <td>2.038462</td>
      <td>1.900524</td>
      <td>1.500000</td>
      <td>1.846154</td>
      <td>11.192308</td>
      <td>4.188482</td>
      <td>5.583333</td>
      <td>11.230769</td>
      <td>80109.653846</td>
      <td>45629.591623</td>
      <td>...</td>
      <td>2082851.0</td>
      <td>8715252.0</td>
      <td>669175.0</td>
      <td>541400.0</td>
      <td>26.0</td>
      <td>191.0</td>
      <td>12.0</td>
      <td>13.0</td>
      <td>223149.982649</td>
      <td>242.0</td>
    </tr>
    <tr>
      <th>21st Century Cyber CS</th>
      <td>4.333333</td>
      <td>4.973684</td>
      <td>5.000000</td>
      <td>6.000000</td>
      <td>14.666667</td>
      <td>7.263158</td>
      <td>7.400000</td>
      <td>9.666667</td>
      <td>104567.000000</td>
      <td>58499.605263</td>
      <td>...</td>
      <td>313701.0</td>
      <td>2222985.0</td>
      <td>325919.0</td>
      <td>268700.0</td>
      <td>3.0</td>
      <td>38.0</td>
      <td>5.0</td>
      <td>3.0</td>
      <td>317817.071930</td>
      <td>49.0</td>
    </tr>
    <tr>
      <th>A W Beattie Career Center</th>
      <td>11.333333</td>
      <td>12.034483</td>
      <td>4.500000</td>
      <td>11.500000</td>
      <td>14.000000</td>
      <td>13.793103</td>
      <td>17.500000</td>
      <td>12.333333</td>
      <td>88516.666667</td>
      <td>60988.655172</td>
      <td>...</td>
      <td>265550.0</td>
      <td>1768671.0</td>
      <td>140756.0</td>
      <td>378989.0</td>
      <td>3.0</td>
      <td>29.0</td>
      <td>2.0</td>
      <td>6.0</td>
      <td>283048.155172</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>ACT Academy Cyber CS</th>
      <td>1.000000</td>
      <td>1.125000</td>
      <td>1.000000</td>
      <td>NaN</td>
      <td>11.000000</td>
      <td>9.500000</td>
      <td>2.000000</td>
      <td>NaN</td>
      <td>89000.000000</td>
      <td>45460.500000</td>
      <td>...</td>
      <td>178000.0</td>
      <td>363684.0</td>
      <td>45000.0</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>8.0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>179460.500000</td>
      <td>11.0</td>
    </tr>
    <tr>
      <th>ARIN IU 28</th>
      <td>11.875000</td>
      <td>11.825000</td>
      <td>13.222222</td>
      <td>20.333333</td>
      <td>15.375000</td>
      <td>13.175000</td>
      <td>15.555556</td>
      <td>20.666667</td>
      <td>92491.000000</td>
      <td>66702.575000</td>
      <td>...</td>
      <td>739928.0</td>
      <td>2668103.0</td>
      <td>1370081.0</td>
      <td>257862.0</td>
      <td>8.0</td>
      <td>40.0</td>
      <td>18.0</td>
      <td>3.0</td>
      <td>321263.186111</td>
      <td>69.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>



In the end, I have two dataframes essentially storing the same information, stacked (or long) is easier for parsing by eye, and unstacked (or wide) is necessary for creating visualizations. 

Again, my primary goal here is to analyze differences in salary on a district-by-district basis.

The first step is a little involved: essentially I want to create a horizontal stacked barplot. This isn't directly supported using the _seaborn_ package; however a workaround is to simply sum the values wanted and then plot the new summed columns superimposed by the smaller column. Maybe this makes sense, the visualization helps. 

However, I also want to order the barplot, which adds some more complication. I can either re-order the dataframe before-hand, or provide a key to re-order the dataframe in the seaborn plot call. While I could accomplish the first step referring to existing variables, accomplishing the ordering is much more difficult. Luckily I can subset my dataframe as a new variable without copying the columns in memory. So at this point, I'm going to spin off a new dataframe specifically for achieving the visualizations I want. While I do this, I'll re-order the dataframe into the order I want for my first visualization.


```python
salary_data = pd.DataFrame(data = {'sums': district_data[('AvgAnnualSalary','Administrative / Supervisory')]+district_data[('AvgAnnualSalary','Classroom Teachers')],
                                   'administrators': district_data[('AvgAnnualSalary','Administrative / Supervisory')],
                                   'teachers': district_data[('AvgAnnualSalary','Classroom Teachers')],
                                   'size': district_data[('TotalPersons')],
                                   'budget': district_data[('TotalAnnualSalary')]}
                        ).sort_values(by=['sums','teachers'],ascending=False)
```


```python
salary_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>administrators</th>
      <th>budget</th>
      <th>size</th>
      <th>sums</th>
      <th>teachers</th>
    </tr>
    <tr>
      <th>SchoolDistrict</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Ridley SD</th>
      <td>147903.266667</td>
      <td>455537.064111</td>
      <td>444.0</td>
      <td>232154.213047</td>
      <td>84250.946381</td>
    </tr>
    <tr>
      <th>Lower Merion SD</th>
      <td>136593.638889</td>
      <td>439765.289907</td>
      <td>805.0</td>
      <td>230954.498645</td>
      <td>94360.859756</td>
    </tr>
    <tr>
      <th>Central Montco Technical High School</th>
      <td>135697.000000</td>
      <td>393172.761905</td>
      <td>29.0</td>
      <td>230932.095238</td>
      <td>95235.095238</td>
    </tr>
    <tr>
      <th>New Hope-Solebury SD</th>
      <td>144960.500000</td>
      <td>422351.138622</td>
      <td>159.0</td>
      <td>230011.045455</td>
      <td>85050.545455</td>
    </tr>
    <tr>
      <th>Wissahickon SD</th>
      <td>138564.058824</td>
      <td>420750.587352</td>
      <td>391.0</td>
      <td>228630.263028</td>
      <td>90066.204204</td>
    </tr>
  </tbody>
</table>
</div>




```python
f, ax = plt.subplots(figsize=(8, 168))

# Plot the administrator pay
sns.set_color_codes("pastel")
sns.barplot(x=salary_data['sums'],
            y=salary_data.index,
            label="Administrators", color="b")

# Plot the crashes where alcohol was involved
sns.set_color_codes("muted")
sns.barplot(x=salary_data['teachers'],
            y=salary_data.index,
            label="Teachers", color="b")

ax.legend(ncol=2, loc="lower right", frameon=True)
ax.set(xlabel="Dollars ($)",
       title="Average Annual Salary by Job Category")
```




    [Text(0.5,0,'Dollars ($)'),
     Text(0.5,1,'Average Annual Salary by Job Category')]




![png](output_38_1.png)


The above graph is a good start, we can see within a school district how the pay ratio is distributed between teachers and administrators. For example, the first school Ridley SD  has the highest overall average annual salaries, but the pay favors administrators a little. However, further down, Global Leadership Academy CS pays their administrators much more on average. 

The problem is that it's difficult to compare school districts against each other. For this, the data needs to be scaled or normalized in some way. For this, I'll instead plot the ratio of the average annual salaries of administrators to teachers. 


```python
row_order = pd.DataFrame(salary_data['administrators']/salary_data['sums']).sort_values(0,ascending=False).index
```


```python

fig1 = plt.figure(1, figsize=(8, 168))
gridspec.GridSpec(169,1)

plt.subplot2grid((169,1), (0,0), rowspan=168, colspan=1)
ratio_plot = sns.stripplot(x=salary_data['administrators']/salary_data['teachers'],
              y=salary_data.index,
              palette="RdYlBu",
              linewidth = 0.5,
              size = 8,
              order = pd.DataFrame(salary_data['administrators']/salary_data['teachers']).sort_values(0,ascending=False).index
             )
ratio_plot.xaxis.grid(False)
ratio_plot.yaxis.grid(True)
ratio_plot.set_xticks([], minor=False)
ratio_plot.set(xlabel="", title="Comparing Average Administrator Salaries to Average Teacher Salaries")
sns.despine(left=True, bottom=True)

plt.subplot2grid((169,1), (168,0), rowspan=1, colspan=1)
ratio_box = sns.boxplot(x=salary_data['administrators']/salary_data['teachers'], palette="RdYlBu")
ratio_box.set_yticks([], minor=False)
ratio_box.set(xlabel="Ratio (Administrator/Teachers)")
sns.despine(left=True, bottom=True)

fig1.tight_layout()

fig1.savefig("F:\\GitHub\\TeacherSalary\\Visualizations\\2015_2016_PA_DistrictSalaryRatio.png")
```


![png](output_41_0.png)


The figure above plots the ratio of the average annual salaries for administrators to teachers, with a boxplot below to summarize the distribution. This allows for districts to be compared on a normalized scale. For example, from the previous plot Global Academy CS appeared fairly imbalanced; in fact, they pay their administrators the most compared to teachers than any other school district. They really are all about leadership! Because there are so many school districts, the boxplot helps flatten the graph. On average, most school districts seem to pay their administrators about 1.5 to 1.75 times as much as their teachers. The tail favors the higher end of course, with a fair number of outliers between 2.25 to 3. But some districts appear to pay their administrators less than their teachers.

I should also discuss the bottom of the plot; where twelve school districts have no data. Earlier I noted that there's no missing data: this is only true to the point that there are no N/A values, but it seems there is at least one missing area of data in that some districts have no administrators on the payroll. A little unusual in and of itself, but this also has implications on the other data: there's no guarantee that the administrators for each district are filling the same sorts of roles. One district may have a fully staffed administration with a Superintendent, Assistant Superintendents, etc.; while another district only lists a Supervisor. It's impossible to tell from just this visualization. As for why these school districts have no administrators, I do explore that a little more in my exploration notebook.

However, there's a final issue I want to address: How impactful are these salary imbalances? Now that there's a basis for comparing districts to each other, it's also important to account for the size of a district. 


```python
fig1, ax1 = plt.subplots(figsize = (12,4))
size_plot = sns.swarmplot(x=salary_data['size'], color='#5b6793', alpha=0.35)
size_plot.set(ylabel='School Districts', xlabel='Size', title='Staff Size of School Districts')
size_plot.set_yticklabels([])
size_plot.set_yticks([], minor=False)
```




    []




![png](output_43_1.png)


Here there's a minor problem. The swarmplot above shows one school district outstrips all the others in terms of size by a massive margin. In fact, the swarmplot is actually so densely concentrated at the bottom as to be deceptive to the level of unbalance. This outlying school district is actually the city of Philadelphia. So far the data hasn't had these sorts of distant outliers. I've left them in to this point, however here I'll consider Philadelphia separately since it's so significantly different in terms of size. 


```python
salary_data_no_phil = salary_data[-(salary_data['size'] > 4000)]
```


```python
fig2, axes = plt.subplots(figsize = (12,10), sharex=True)
plt.suptitle("Distribution of District Sizes (Excluding Philadelphia)", fontsize=15)

plt.subplot2grid((4,3),(0,0), rowspan=2, colspan = 3)
figsub2a = sns.swarmplot(salary_data_no_phil['size'], color='#5b6793', alpha=0.35)
figsub2a.set(ylabel="School Districts")
figsub2a.yaxis.labelpad = 30
figsub2a.set_yticklabels([])
figsub2a.set_yticks([], minor=False)
figsub2a.xaxis.label.set_visible(False)

plt.subplot2grid((4,3),(2,0), rowspan=1, colspan = 3)
figsub2b = sns.distplot(salary_data_no_phil['size'], color='#5b6793', kde=False, bins=100)
figsub2b.set(xlabel="Size", ylabel="School Districts")
```




    [Text(0,0.5,'School Districts'), Text(0.5,0,'Size')]




![png](output_46_1.png)


Without Philadelphia the distribution of sizes clears up a little bit. The swarmplot plots all data points, which is useful for visualizing the distribution of the larger school districts, but performs poorly with the hundreds of small school districts. The histogram on the other hand, has the opposite problem. Putting them together helps balance the other..

For reference, unsurprisingly the second largest district is Pittsburgh.


```python
salary_data[salary_data['size'] > 2000]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>administrators</th>
      <th>budget</th>
      <th>size</th>
      <th>sums</th>
      <th>teachers</th>
    </tr>
    <tr>
      <th>SchoolDistrict</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Pittsburgh SD</th>
      <td>110791.898305</td>
      <td>352185.039925</td>
      <td>2309.0</td>
      <td>184437.671800</td>
      <td>73645.773495</td>
    </tr>
    <tr>
      <th>Philadelphia City SD</th>
      <td>113019.222997</td>
      <td>330501.219660</td>
      <td>9155.0</td>
      <td>182755.854897</td>
      <td>69736.631901</td>
    </tr>
  </tbody>
</table>
</div>



So now to compare salary ratios to district sizes:


```python
fig3 = sns.jointplot(x=salary_data_no_phil['size'],
              y=salary_data_no_phil['administrators']/salary_data_no_phil['teachers'], 
              color='#5b6793', alpha=0.5)
fig3.fig.set_figwidth(8)
fig3.fig.set_figheight(8)
plt.suptitle("Comparing Salary Ratios to Size for School Districts", fontsize=15, y =1.02)
fig3.set_axis_labels('Size','Salary Ratio (Adminstrators/Teachers)')
```




    <seaborn.axisgrid.JointGrid at 0x1a53a322e48>




![png](output_50_1.png)



```python
(salary_data_no_phil['administrators']/salary_data_no_phil['teachers']).mean()
```




    1.672584830144329




```python
(salary_data_no_phil['administrators']/salary_data_no_phil['teachers']).std()
```




    0.2902317754726339



The main plot is a scatter plot of districts based on their size and the salary ratio. However, there are additional histograms on the x- and y-axes giving their respective distributions. Size was shown above, while the y-axis shows the salary ratios and their distributions, which approximates a normal distribution around 1.67 with a standard deviation of 0.29, roughly. 

From the plot it appears that as district size grows, the salary ratio regresses to the mean salary ratio. Smaller districts are where the major variations in salary ratio occur. So overall, the salary disparity between teachers and administrators is not unusually large:

* Salary ratios around and above 2.0 or higher are in school districts smaller than 500 people.
* Salary ratios around and above 2.5 or higher are in school districts smaller than 200 people.

However I also included another metric for district size: the budget. The first step is exclusionary: if district budget is strongly correlated with district size, then there should be little difference in the resulting analysis. If the correlation is weak, there might be grounds for further exploration.


```python
fig4 = sns.jointplot(x=salary_data_no_phil['size'],
              y=salary_data_no_phil['budget'], 
              color='#5b6793', alpha=0.35)
fig4.fig.set_figwidth(8)
fig4.fig.set_figheight(8)
```


![png](output_54_0.png)



```python
fig5 = sns.lmplot(x="size",y="budget", data = salary_data_no_phil)
fig5.fig.set_figwidth(8)
fig5.fig.set_figheight(8)
```


![png](output_55_0.png)


So the correlation coefficient is 0.51, with a p-value well below 0.05; but a look at the plot shows that the two don't really show a tight correlation pattern. It looks like a very tight, nearly vertical grouping with a wide scatter to the right. In the linear regression plot below, actually provides an interesting contrast where the linear regression line is very different.

However, there's actually a lot of scatter in both plots. This looks like a situation where the variables are widely but evenly scattered. 


```python
fig6 = sns.jointplot(x=salary_data['budget'],
              y=salary_data['administrators']/salary_data['teachers'], 
              color='#5b6793', alpha=0.5)
fig6.fig.set_figwidth(8)
fig6.fig.set_figheight(8)
plt.suptitle("Comparing Salary Ratios to Budget for School Districts", fontsize=15, y =1.02)
fig6.set_axis_labels('Budget','Salary Ratio (Adminstrators/Teachers)')
```




    <seaborn.axisgrid.JointGrid at 0x1a544555dd8>




![png](output_57_1.png)



```python
salary_data['budget'].mean()
```




    265441.3656201442




```python
salary_data['budget'].std()
```




    65416.49826725662



So this plot is actually less useful. Essentially, both variables roughly follow normal distributions; and plotted against each other, there's a dense core in this plot, with fairly even scatter in all directions that's difficult to draw conclusions from. There's also a second sneaky note here: Philadelphia is actually not excluded here, making it just that much more interesting, but I'll get into that lter. With the plot of district size vs salary ratios, there were some takeaways in terms of district sizes. So why aren't there any similar takeaways here?

This carries over from the plot of size vs budget: the size of a school district doesn't correlate well with the budget of a school district. The two plots of salary ratio vs size and vs budget, respectively, should be strongly similar if size and budget were indeed strongly correlated; clearly they are not. Here, most schools of all budget sizes have average 1.65 ratio of average administrator to teacher salaries; but variations occur. And those variations do take on a hint of that linear regression line and the weak correlation in the two variables. Most of the variations have an increasing ratio discrepancy as budget increases. Essentially, quadrants 1 and 3 have outliers, 2 and 4 have fewer.

In conclusion:

* There are significantly more teachers than administrators.
* In general, annual salaries roughly follow a right-skewed normal distribution which is stronger the more people there are (i.e. it's heavily pronounced for teachers, weaker for administrators)
* The ratio of average annual salaries of administrators to teachers is also roughly normal distribution, with mean at 1.67 and a standard deviation of 0.3
* Most school districts are very small, with decreasing numbers of school districts of larger and larger sizes.
* Most school districts have an average total budget for salaries that is normally distributed with a mean of \$265,441 and a standard deviation of \$65,416.
* School district size isn't strongly correlated with school district budget.
* Salary ratios around and above 2.0 or higher are in school districts smaller than 500 people.
* Salary ratios around and above 2.5 or higher are in school districts smaller than 200 people.

I'll look into the other variables in further parts, as well as the outliers I've identified here. There's also my exploration notebook using R where I get into some of the rougher ground work for this notebook, with corresponding project notes.

___
_2018 | Bernard Kung _
___
